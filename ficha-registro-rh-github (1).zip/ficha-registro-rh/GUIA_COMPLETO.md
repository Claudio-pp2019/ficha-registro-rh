# 📘 Guia Completo - Sistema de Ficha de Registro RH

## 🎯 Visão Geral

Sistema completo para gerenciamento de fichas de registro de funcionários com três formas de compartilhamento:

1. **📱 Local** - Mesmo computador/navegador (LocalStorage)
2. **📤 Exportar/Importar** - Compartilhar via arquivo JSON
3. **🌐 Sincronização Online** - Backend com API REST

---

## 📋 Cenários de Uso

### Cenário 1: Funcionário e RH no mesmo computador

**Fluxo:**
1. Funcionário preenche seus dados
2. Clica em "Salvar ficha"
3. RH clica em "Carregar ficha"
4. Digita o CPF do funcionário
5. Completa com dados da empresa
6. Gera PDF final

**Tecnologia:** LocalStorage (automático)

---

### Cenário 2: Funcionário em casa, RH no escritório

**Opção A - Exportar/Importar (Recomendado para começar)**

**Funcionário:**
1. Preenche seus dados
2. Anexa documentos (RG, CTPS, etc.)
3. Clica em "📤 Exportar ficha"
4. Envia o arquivo `.json` por e-mail/WhatsApp

**RH:**
1. Recebe o arquivo `.json`
2. Clica em "📥 Importar ficha"
3. Seleciona o arquivo
4. Completa com dados da empresa
5. Clica em "Salvar ficha"
6. Gera PDF final

**Vantagens:**
- ✅ Funciona offline
- ✅ Sem necessidade de servidor
- ✅ Simples e rápido
- ✅ Todos os dados e documentos preservados

---

**Opção B - Sincronização Online (Requer backend)**

**Funcionário:**
1. Preenche seus dados
2. Anexa documentos
3. Clica em "🌐 Sincronizar online"
4. Dados são enviados para o servidor

**RH:**
1. Clica em "Carregar ficha"
2. Digita o CPF
3. Sistema busca automaticamente no servidor
4. Completa com dados da empresa
5. Clica em "🌐 Sincronizar online" novamente
6. Gera PDF final

**Vantagens:**
- ✅ Sincronização automática
- ✅ Acesso de qualquer lugar
- ✅ Histórico de alterações
- ✅ Backup centralizado

**Desvantagens:**
- ❌ Requer servidor configurado
- ❌ Necessita internet

---

## 🚀 Instalação

### Frontend (Arquivo HTML)

1. **Copie o código** do arquivo `ficha-registro-final.html`
2. **Cole no VSCode** ou editor de texto
3. **Salve como** `ficha-registro.html`
4. **Abra no navegador** (duplo clique)

Pronto! O sistema já funciona com LocalStorage e Exportar/Importar.

---

### Backend (Opcional - para sincronização online)

#### Pré-requisitos:
- Node.js instalado (versão 14 ou superior)

#### Passo a passo:

**1. Instalar dependências:**
```bash
cd ficha-backend
npm install
```

**2. Iniciar servidor:**
```bash
npm start
```

**3. Configurar frontend:**

No arquivo HTML, localize a linha:
```javascript
const API_BACKEND = 'https://seu-backend.com/api';
```

Altere para:
```javascript
const API_BACKEND = 'http://localhost:3000/api';
```

**4. Testar:**
- Abra o HTML no navegador
- Preencha uma ficha
- Clique em "🌐 Sincronizar online"
- Deve aparecer mensagem de sucesso

---

## 📖 Como Usar - Passo a Passo

### Para o Funcionário:

#### 1. Preencher Dados Pessoais
- Nome completo
- CPF, RG
- Data de nascimento
- Endereço, telefone, e-mail
- Nome dos pais

#### 2. Anexar Documentos
Para cada documento, anexe **frente e verso**:

- **RG** (frente e verso)
- **CTPS** (frente e verso)
- **Comprovante de Endereço** (frente e verso)
- **Certificado de Reservista** (se masculino)

**Opções:**
- 📎 Anexar arquivo (JPG ou PDF)
- 📷 Tirar foto com a câmera

#### 3. Adicionar Dependentes (se houver)
- Nome completo
- Parentesco (filho, cônjuge, etc.)
- Data de nascimento

#### 4. Compartilhar com RH

**Opção 1 - Exportar:**
1. Clique em "📤 Exportar ficha"
2. Arquivo `.json` será baixado
3. Envie por e-mail/WhatsApp

**Opção 2 - Sincronizar:**
1. Clique em "🌐 Sincronizar online"
2. Informe o CPF ao RH

---

### Para o RH:

#### 1. Receber Ficha do Funcionário

**Se recebeu arquivo JSON:**
1. Clique em "📥 Importar ficha"
2. Selecione o arquivo
3. Dados são carregados automaticamente

**Se funcionário sincronizou online:**
1. Clique em "Carregar ficha"
2. Digite o CPF
3. Dados são buscados do servidor

#### 2. Completar Dados da Empresa
- Razão social
- CNPJ
- Endereço da empresa
- CNAE
- Responsável

#### 3. Dados da Admissão e Contrato
- Data de admissão
- Tipo de contrato
- Cargo/função
- CBO
- Setor
- Jornada de trabalho
- Salário base
- Dados bancários

#### 4. Salvar e Gerar PDF
1. Clique em "Salvar ficha"
2. Clique em "Salvar em PDF"
3. PDF completo com todos os documentos será baixado

#### 5. Enviar para Contabilidade
- PDF inclui todos os dados
- Documentos anexados aparecem no final
- Pronto para enviar!

---

## 🔧 Funcionalidades Técnicas

### Auto-Save
- ✅ Salva rascunho automaticamente a cada 3 segundos
- ✅ Recupera ao reabrir o navegador
- ✅ Pergunta se deseja continuar de onde parou

### Validações
- ✅ CPF válido (dígitos verificadores)
- ✅ CNPJ válido
- ✅ E-mail válido
- ✅ Telefone válido (10 ou 11 dígitos)
- ✅ Idade mínima 16 anos
- ✅ Campos obrigatórios marcados

### Máscaras Automáticas
- ✅ CPF: 000.000.000-00
- ✅ CNPJ: 00.000.000/0001-00
- ✅ Telefone: (00) 00000-0000
- ✅ CEP: 00000-000
- ✅ Moeda: R$ 0.000,00

### Busca de CEP
- ✅ Integração com ViaCEP
- ✅ Preenchimento automático de endereço
- ✅ Funciona ao sair do campo CEP

### Sistema de Notificações
- ✅ Notificações visuais modernas
- ✅ Tipos: Sucesso, Erro, Info, Aviso
- ✅ Fechamento automático após 5 segundos
- ✅ Botão para fechar manualmente

---

## 📄 Estrutura do PDF Gerado

1. **Cabeçalho**
   - Logo da empresa
   - Foto do funcionário
   - Título

2. **Dados da Empresa**
   - Razão social, CNPJ, endereço, etc.

3. **Dados Pessoais**
   - Nome, CPF, RG, filiação, etc.

4. **Contato e Endereço**
   - CEP, endereço, telefone, e-mail

5. **Carteira de Trabalho**
   - Número, série, UF, emissão

6. **Admissão e Contrato**
   - Data, cargo, salário, jornada, etc.

7. **Dados Bancários**
   - Banco, agência, conta, PIX

8. **Dependentes** (se houver)
   - Tabela com nome, parentesco, nascimento

9. **Documentos Anexados** ⭐ NOVO
   - RG - Frente e Verso
   - CTPS - Frente e Verso
   - Comprovante - Frente e Verso
   - Reservista - Frente e Verso (se aplicável)
   - Imagens em alta resolução
   - Nome do arquivo de cada documento

10. **Rodapé**
    - Número da página
    - Data e hora de geração

---

## 🔒 Segurança e Privacidade

### LocalStorage
- ✅ Dados ficam apenas no navegador do usuário
- ✅ Não são enviados para nenhum servidor
- ✅ Privacidade total

### Exportar/Importar
- ✅ Usuário controla o arquivo
- ✅ Pode criptografar antes de enviar
- ✅ Sem dependência de terceiros

### Backend (se usar)
- ⚠️ Dados armazenados no servidor
- ⚠️ Recomenda-se adicionar autenticação
- ⚠️ Use HTTPS em produção
- ⚠️ Implemente backup regular

---

## 🐛 Solução de Problemas

### "Documentos não aparecem no PDF"
✅ **Resolvido!** A versão atual inclui todos os documentos no PDF.

### "Não consigo importar a ficha"
- Verifique se o arquivo é `.json`
- Certifique-se que não foi corrompido
- Tente exportar novamente

### "Sincronização online não funciona"
- Verifique se o backend está rodando
- Confirme a URL da API no código
- Veja o console do navegador (F12) para erros

### "Foto/documento não carrega"
- Verifique o tamanho (máximo 5MB)
- Use apenas JPG ou PDF
- Tente tirar foto novamente

### "CPF inválido"
- Digite apenas números ou use a máscara
- Verifique os dígitos verificadores
- CPF deve ter 11 dígitos

---

## 📊 Comparação das Opções

| Recurso | LocalStorage | Exportar/Importar | Backend Online |
|---------|--------------|-------------------|----------------|
| **Configuração** | Nenhuma | Nenhuma | Requer servidor |
| **Internet** | Não precisa | Não precisa | Necessário |
| **Compartilhar** | Mesmo PC | Arquivo | Automático |
| **Backup** | Manual | Arquivo é backup | Centralizado |
| **Segurança** | Alta | Alta | Configurável |
| **Custo** | Grátis | Grátis | Servidor pago |
| **Complexidade** | Baixa | Baixa | Média |

---

## 🎓 Recomendações

### Para Pequenas Empresas (até 10 funcionários):
👉 Use **Exportar/Importar**
- Simples e eficaz
- Sem custos
- Funciona offline

### Para Médias Empresas (10-100 funcionários):
👉 Use **Backend Online**
- Centralização
- Histórico
- Múltiplos usuários

### Para Grandes Empresas (100+ funcionários):
👉 Integre com sistema ERP existente
- Use a API como base
- Adicione autenticação robusta
- Implemente auditoria

---

## 📞 Próximos Passos

### Melhorias Futuras Sugeridas:

1. **Autenticação**
   - Login de usuários
   - Níveis de acesso (funcionário/RH/admin)

2. **Assinatura Digital**
   - Assinar documentos eletronicamente
   - Validade jurídica

3. **Integração com eSocial**
   - Envio automático para o governo
   - Validação de dados

4. **Dashboard**
   - Visualização de todas as fichas
   - Relatórios e estatísticas

5. **Notificações**
   - E-mail quando funcionário preencher
   - Lembretes de documentos pendentes

6. **Versionamento**
   - Histórico de alterações
   - Restaurar versões anteriores

7. **Exportação em Lote**
   - Gerar PDFs de múltiplos funcionários
   - Exportar para Excel/CSV

---

## ✅ Checklist de Implementação

### Fase 1 - Básico (Atual) ✅
- [x] Formulário completo
- [x] Validações
- [x] Máscaras
- [x] Upload de documentos (frente e verso)
- [x] Geração de PDF com documentos
- [x] LocalStorage
- [x] Auto-save
- [x] Exportar/Importar

### Fase 2 - Backend (Opcional) ✅
- [x] API REST
- [x] Sincronização online
- [x] Armazenamento em servidor

### Fase 3 - Melhorias (Futuro)
- [ ] Autenticação
- [ ] Dashboard
- [ ] Assinatura digital
- [ ] Integração eSocial
- [ ] Notificações por e-mail
- [ ] Versionamento

---

## 📝 Notas Importantes

1. **Formato de Documentos:** Apenas JPG e PDF são aceitos
2. **Tamanho Máximo:** 5MB por arquivo
3. **Frente e Verso:** Obrigatório para todos os documentos
4. **CPF:** Usado como identificador único
5. **Backup:** Sempre faça backup dos arquivos JSON exportados
6. **Navegador:** Recomendado Chrome, Firefox ou Edge atualizados
7. **Câmera:** Requer HTTPS para funcionar (ou localhost)

---

## 🎉 Conclusão

Você agora tem um sistema completo de gerenciamento de fichas de registro de funcionários com três formas de compartilhamento:

1. ✅ **LocalStorage** - Para uso no mesmo computador
2. ✅ **Exportar/Importar** - Para compartilhar entre dispositivos
3. ✅ **Backend Online** - Para sincronização automática

Escolha a opção que melhor se adapta às suas necessidades e comece a usar!

**Dúvidas?** Revise este guia ou consulte o README.md do backend.

---

**Desenvolvido com ❤️ para facilitar o trabalho do RH**

