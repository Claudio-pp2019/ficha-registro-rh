# 🌐 Backend de Sincronização - Ficha de Registro RH

Backend simples em Node.js + Express para sincronização de fichas de registro de funcionários entre dispositivos.

## 📋 Funcionalidades

- ✅ API REST completa para gerenciar fichas
- ✅ Armazenamento em arquivos JSON (sem necessidade de banco de dados)
- ✅ Suporte a imagens em base64 (documentos anexados)
- ✅ CORS habilitado para acesso do frontend
- ✅ Validação de CPF
- ✅ Listagem, criação, leitura e exclusão de fichas

## 🚀 Como Usar

### 1. Instalar dependências

```bash
cd ficha-backend
npm install
```

### 2. Iniciar o servidor

```bash
npm start
```

O servidor iniciará em `http://localhost:3000`

### 3. Configurar o frontend

No arquivo HTML, altere a linha:

```javascript
const API_BACKEND = 'https://seu-backend.com/api';
```

Para:

```javascript
const API_BACKEND = 'http://localhost:3000/api';
```

## 📡 Rotas da API

### Health Check
```
GET /api/health
```

Retorna o status do servidor.

**Resposta:**
```json
{
  "status": "online",
  "timestamp": "2025-01-15T10:30:00.000Z",
  "versao": "1.0"
}
```

---

### Criar/Atualizar Ficha
```
POST /api/fichas
```

**Body:**
```json
{
  "cpf": "12345678900",
  "dados": {
    "nome": "João Silva",
    "email": "joao@exemplo.com",
    "telefone": "(11) 98765-4321",
    "documentos": { ... },
    ...
  }
}
```

**Resposta:**
```json
{
  "sucesso": true,
  "mensagem": "Ficha salva com sucesso",
  "id": "12345678900",
  "ultimaAtualizacao": "2025-01-15T10:30:00.000Z"
}
```

---

### Buscar Ficha por CPF
```
GET /api/fichas/:cpf
```

**Exemplo:**
```
GET /api/fichas/12345678900
```

**Resposta:**
```json
{
  "sucesso": true,
  "dados": {
    "nome": "João Silva",
    "email": "joao@exemplo.com",
    ...
  },
  "ultimaAtualizacao": "2025-01-15T10:30:00.000Z"
}
```

---

### Listar Todas as Fichas
```
GET /api/fichas
```

**Resposta:**
```json
{
  "sucesso": true,
  "total": 5,
  "fichas": [
    {
      "cpf": "12345678900",
      "nome": "João Silva",
      "ultimaAtualizacao": "2025-01-15T10:30:00.000Z"
    },
    ...
  ]
}
```

---

### Deletar Ficha
```
DELETE /api/fichas/:cpf
```

**Exemplo:**
```
DELETE /api/fichas/12345678900
```

**Resposta:**
```json
{
  "sucesso": true,
  "mensagem": "Ficha deletada com sucesso"
}
```

## 📁 Estrutura de Arquivos

```
ficha-backend/
├── server.js          # Servidor principal
├── package.json       # Dependências
├── README.md          # Este arquivo
└── data/              # Fichas salvas (criado automaticamente)
    ├── 12345678900.json
    ├── 98765432100.json
    └── ...
```

## 🔒 Segurança

⚠️ **IMPORTANTE:** Este é um backend básico para desenvolvimento/uso interno.

Para produção, considere adicionar:

- 🔐 Autenticação (JWT, OAuth)
- 🔑 Autorização (controle de acesso)
- 🛡️ Rate limiting
- 📝 Logs estruturados
- 💾 Banco de dados (PostgreSQL, MongoDB)
- 🔒 HTTPS obrigatório
- 🧪 Testes automatizados

## 🌐 Deploy em Produção

### Opção 1: Heroku

1. Criar conta no Heroku
2. Instalar Heroku CLI
3. Deploy:

```bash
heroku create minha-ficha-rh
git init
git add .
git commit -m "Initial commit"
git push heroku main
```

### Opção 2: Railway

1. Criar conta no Railway
2. Conectar repositório GitHub
3. Deploy automático

### Opção 3: VPS (DigitalOcean, AWS, etc.)

1. Configurar servidor Node.js
2. Usar PM2 para gerenciar processo
3. Configurar Nginx como proxy reverso
4. Configurar SSL com Let's Encrypt

```bash
# Instalar PM2
npm install -g pm2

# Iniciar servidor
pm2 start server.js --name ficha-backend

# Salvar configuração
pm2 save
pm2 startup
```

## 🧪 Testar a API

### Com curl:

```bash
# Health check
curl http://localhost:3000/api/health

# Criar ficha
curl -X POST http://localhost:3000/api/fichas \
  -H "Content-Type: application/json" \
  -d '{"cpf":"12345678900","dados":{"nome":"João Silva"}}'

# Buscar ficha
curl http://localhost:3000/api/fichas/12345678900

# Listar fichas
curl http://localhost:3000/api/fichas
```

### Com Postman ou Insomnia:

Importe as rotas acima e teste diretamente.

## 📞 Suporte

Para dúvidas ou problemas, verifique:

1. Se o Node.js está instalado (`node --version`)
2. Se as dependências foram instaladas (`npm install`)
3. Se a porta 3000 está disponível
4. Se o CORS está configurado corretamente

## 📄 Licença

MIT

