const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const fs = require('fs').promises;
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_DIR = path.join(__dirname, 'data');

// Middleware
app.use(cors());
app.use(bodyParser.json({ limit: '50mb' })); // Aumentar limite para suportar imagens base64
app.use(bodyParser.urlencoded({ extended: true, limit: '50mb' }));

// Criar diretório de dados se não existir
async function inicializarDiretorio() {
  try {
    await fs.access(DATA_DIR);
  } catch {
    await fs.mkdir(DATA_DIR, { recursive: true });
    console.log('📁 Diretório de dados criado:', DATA_DIR);
  }
}

// Função auxiliar para salvar ficha
async function salvarFicha(cpf, dados) {
  const arquivo = path.join(DATA_DIR, `${cpf}.json`);
  const fichaCompleta = {
    cpf,
    dados,
    ultimaAtualizacao: new Date().toISOString(),
    versao: '1.0'
  };
  await fs.writeFile(arquivo, JSON.stringify(fichaCompleta, null, 2), 'utf8');
  return fichaCompleta;
}

// Função auxiliar para carregar ficha
async function carregarFicha(cpf) {
  const arquivo = path.join(DATA_DIR, `${cpf}.json`);
  try {
    const conteudo = await fs.readFile(arquivo, 'utf8');
    return JSON.parse(conteudo);
  } catch (erro) {
    if (erro.code === 'ENOENT') {
      return null;
    }
    throw erro;
  }
}

// Função auxiliar para listar todas as fichas
async function listarTodasFichas() {
  try {
    const arquivos = await fs.readdir(DATA_DIR);
    const fichas = [];
    
    for (const arquivo of arquivos) {
      if (arquivo.endsWith('.json')) {
        const conteudo = await fs.readFile(path.join(DATA_DIR, arquivo), 'utf8');
        const ficha = JSON.parse(conteudo);
        
        // Retornar apenas metadados, não os dados completos
        fichas.push({
          cpf: ficha.cpf,
          nome: ficha.dados.nome || 'Sem nome',
          ultimaAtualizacao: ficha.ultimaAtualizacao
        });
      }
    }
    
    return fichas;
  } catch (erro) {
    return [];
  }
}

// ========== ROTAS DA API ==========

// Rota de health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'online',
    timestamp: new Date().toISOString(),
    versao: '1.0'
  });
});

// Criar ou atualizar ficha
app.post('/api/fichas', async (req, res) => {
  try {
    const { cpf, dados } = req.body;
    
    if (!cpf || !dados) {
      return res.status(400).json({
        erro: 'CPF e dados são obrigatórios'
      });
    }
    
    const cpfLimpo = cpf.replace(/\D/g, '');
    
    if (cpfLimpo.length !== 11) {
      return res.status(400).json({
        erro: 'CPF inválido'
      });
    }
    
    const ficha = await salvarFicha(cpfLimpo, dados);
    
    res.status(201).json({
      sucesso: true,
      mensagem: 'Ficha salva com sucesso',
      id: cpfLimpo,
      ultimaAtualizacao: ficha.ultimaAtualizacao
    });
    
    console.log(`✅ Ficha salva: ${dados.nome || 'Sem nome'} (CPF: ${cpfLimpo})`);
    
  } catch (erro) {
    console.error('Erro ao salvar ficha:', erro);
    res.status(500).json({
      erro: 'Erro ao salvar ficha',
      detalhes: erro.message
    });
  }
});

// Buscar ficha por CPF
app.get('/api/fichas/:cpf', async (req, res) => {
  try {
    const cpfLimpo = req.params.cpf.replace(/\D/g, '');
    
    if (cpfLimpo.length !== 11) {
      return res.status(400).json({
        erro: 'CPF inválido'
      });
    }
    
    const ficha = await carregarFicha(cpfLimpo);
    
    if (!ficha) {
      return res.status(404).json({
        erro: 'Ficha não encontrada'
      });
    }
    
    res.json({
      sucesso: true,
      dados: ficha.dados,
      ultimaAtualizacao: ficha.ultimaAtualizacao
    });
    
    console.log(`📥 Ficha carregada: ${ficha.dados.nome || 'Sem nome'} (CPF: ${cpfLimpo})`);
    
  } catch (erro) {
    console.error('Erro ao carregar ficha:', erro);
    res.status(500).json({
      erro: 'Erro ao carregar ficha',
      detalhes: erro.message
    });
  }
});

// Listar todas as fichas (apenas metadados)
app.get('/api/fichas', async (req, res) => {
  try {
    const fichas = await listarTodasFichas();
    
    res.json({
      sucesso: true,
      total: fichas.length,
      fichas
    });
    
  } catch (erro) {
    console.error('Erro ao listar fichas:', erro);
    res.status(500).json({
      erro: 'Erro ao listar fichas',
      detalhes: erro.message
    });
  }
});

// Deletar ficha
app.delete('/api/fichas/:cpf', async (req, res) => {
  try {
    const cpfLimpo = req.params.cpf.replace(/\D/g, '');
    
    if (cpfLimpo.length !== 11) {
      return res.status(400).json({
        erro: 'CPF inválido'
      });
    }
    
    const arquivo = path.join(DATA_DIR, `${cpfLimpo}.json`);
    
    try {
      await fs.unlink(arquivo);
      
      res.json({
        sucesso: true,
        mensagem: 'Ficha deletada com sucesso'
      });
      
      console.log(`🗑️  Ficha deletada: CPF ${cpfLimpo}`);
      
    } catch (erro) {
      if (erro.code === 'ENOENT') {
        return res.status(404).json({
          erro: 'Ficha não encontrada'
        });
      }
      throw erro;
    }
    
  } catch (erro) {
    console.error('Erro ao deletar ficha:', erro);
    res.status(500).json({
      erro: 'Erro ao deletar ficha',
      detalhes: erro.message
    });
  }
});

// Rota 404
app.use((req, res) => {
  res.status(404).json({
    erro: 'Rota não encontrada',
    rota: req.path
  });
});

// Inicializar servidor
async function iniciarServidor() {
  await inicializarDiretorio();
  
  app.listen(PORT, () => {
    console.log('');
    console.log('🚀 ========================================');
    console.log('🚀  Servidor de Fichas RH Online');
    console.log('🚀 ========================================');
    console.log('');
    console.log(`📡 Servidor rodando em: http://localhost:${PORT}`);
    console.log(`📁 Dados salvos em: ${DATA_DIR}`);
    console.log('');
    console.log('📋 Rotas disponíveis:');
    console.log(`   GET    /api/health           - Status do servidor`);
    console.log(`   POST   /api/fichas           - Criar/atualizar ficha`);
    console.log(`   GET    /api/fichas           - Listar todas as fichas`);
    console.log(`   GET    /api/fichas/:cpf      - Buscar ficha por CPF`);
    console.log(`   DELETE /api/fichas/:cpf      - Deletar ficha`);
    console.log('');
    console.log('✅ Pronto para receber requisições!');
    console.log('');
  });
}

iniciarServidor().catch(erro => {
  console.error('❌ Erro ao iniciar servidor:', erro);
  process.exit(1);
});

