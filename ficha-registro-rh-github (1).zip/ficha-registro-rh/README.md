# 📋 Sistema de Ficha de Registro RH

Sistema completo para gerenciamento de fichas de registro de funcionários com upload de documentos, validações automáticas e geração de PDF.

![Status](https://img.shields.io/badge/status-ativo-success)
![Versão](https://img.shields.io/badge/vers%C3%A3o-1.0.0-blue)
![Licença](https://img.shields.io/badge/licen%C3%A7a-MIT-green)

## 🎯 Funcionalidades

### 📝 Formulário Completo
- ✅ Dados da empresa (razão social, CNPJ, endereço)
- ✅ Dados pessoais do funcionário
- ✅ Documentos com frente e verso (RG, CTPS, comprovante, reservista)
- ✅ Dados de admissão e contrato
- ✅ Dados bancários
- ✅ Dependentes

### 📎 Upload de Documentos
- ✅ Frente e verso para cada documento
- ✅ Apenas JPG e PDF aceitos
- ✅ Opção de tirar foto ou anexar arquivo
- ✅ Preview das imagens
- ✅ Validação de tamanho (máx 5MB)

### 🔒 Validações Automáticas
- ✅ CPF válido (dígitos verificadores)
- ✅ CNPJ válido
- ✅ E-mail válido
- ✅ Telefone válido (10 ou 11 dígitos)
- ✅ Idade mínima 16 anos
- ✅ Campos obrigatórios

### 🎨 Máscaras de Formatação
- ✅ CPF: `000.000.000-00`
- ✅ CNPJ: `00.000.000/0001-00`
- ✅ Telefone: `(00) 00000-0000`
- ✅ CEP: `00000-000`
- ✅ Moeda: `R$ 0.000,00`

### 💾 Persistência de Dados
- ✅ **LocalStorage** - Salvar no navegador
- ✅ **Exportar/Importar** - Compartilhar via arquivo JSON
- ✅ **Sincronização Online** - Backend com API REST (opcional)
- ✅ Auto-save a cada 3 segundos
- ✅ Recuperação de rascunho

### 📄 Geração de PDF
- ✅ PDF completo com todos os campos
- ✅ Logo da empresa e foto do funcionário
- ✅ Tabela de dependentes
- ✅ **Documentos anexados com imagens em alta resolução**
- ✅ Frente e verso identificados
- ✅ Paginação automática
- ✅ Rodapé com data e número de página

### 🌐 Extras
- ✅ Busca automática de CEP (integração com ViaCEP)
- ✅ Sistema de notificações moderno
- ✅ Design responsivo (mobile-friendly)
- ✅ Câmera para capturar documentos
- ✅ Modo claro/escuro automático

## 🚀 Como Usar

### Opção 1: Usar Diretamente (Sem Instalação)

1. Baixe o arquivo `index.html`
2. Abra no navegador (duplo clique)
3. Pronto! O sistema já funciona

### Opção 2: Clonar o Repositório

```bash
git clone https://github.com/SEU-USUARIO/ficha-registro-rh.git
cd ficha-registro-rh
```

Abra o arquivo `index.html` no navegador.

### Opção 3: Com Backend (Sincronização Online)

```bash
# Instalar dependências
cd ficha-backend
npm install

# Iniciar servidor
npm start
```

Configure a URL do backend no arquivo `index.html`:
```javascript
const API_BACKEND = 'http://localhost:3000/api';
```

## 📖 Guia de Uso

### Para o Funcionário:

1. **Preencher dados pessoais**
   - Nome, CPF, RG, endereço, etc.

2. **Anexar documentos** (frente e verso)
   - RG
   - CTPS
   - Comprovante de endereço
   - Certificado de reservista (se masculino)

3. **Compartilhar com RH**
   - Clique em "📤 Exportar ficha"
   - Envie o arquivo `.json` por e-mail/WhatsApp

### Para o RH:

1. **Receber ficha do funcionário**
   - Clique em "📥 Importar ficha"
   - Selecione o arquivo recebido

2. **Completar dados**
   - Dados da empresa
   - Dados de admissão e contrato
   - Salário e dados bancários

3. **Gerar PDF**
   - Clique em "Salvar em PDF"
   - PDF completo com todos os documentos será baixado

## 📊 Estrutura do Projeto

```
ficha-registro-rh/
├── index.html              # Sistema completo (frontend)
├── README.md               # Este arquivo
├── GUIA_COMPLETO.md        # Guia detalhado de uso
└── ficha-backend/          # Backend opcional
    ├── server.js           # Servidor Node.js
    ├── package.json        # Dependências
    ├── README.md           # Documentação do backend
    └── .gitignore          # Arquivos ignorados
```

## 🔄 Fluxo de Trabalho

### Cenário 1: Mesmo Computador
```
Funcionário preenche → Salva → RH carrega por CPF → Completa → Gera PDF
```

### Cenário 2: Computadores Diferentes (Recomendado)
```
Funcionário preenche → Exporta JSON → Envia arquivo → RH importa → Completa → Gera PDF
```

### Cenário 3: Com Backend
```
Funcionário preenche → Sincroniza online → RH busca por CPF → Completa → Gera PDF
```

## 🛠️ Tecnologias Utilizadas

### Frontend
- HTML5
- CSS3 (Design moderno e responsivo)
- JavaScript (ES6+)
- [jsPDF](https://github.com/parallax/jsPDF) - Geração de PDF
- [jsPDF-AutoTable](https://github.com/simonbengtsson/jsPDF-AutoTable) - Tabelas no PDF
- [ViaCEP API](https://viacep.com.br/) - Busca de endereço por CEP

### Backend (Opcional)
- Node.js
- Express
- CORS
- Body-parser

## 📋 Requisitos

### Frontend
- Navegador moderno (Chrome, Firefox, Edge, Safari)
- JavaScript habilitado
- Câmera (opcional, para tirar fotos)

### Backend (Opcional)
- Node.js 14 ou superior
- npm ou yarn

## 🔒 Segurança e Privacidade

### LocalStorage
- ✅ Dados ficam apenas no navegador do usuário
- ✅ Não são enviados para nenhum servidor
- ✅ Privacidade total

### Exportar/Importar
- ✅ Usuário controla o arquivo
- ✅ Pode criptografar antes de enviar
- ✅ Sem dependência de terceiros

### Backend (se usar)
- ⚠️ Dados armazenados no servidor
- ⚠️ Recomenda-se adicionar autenticação
- ⚠️ Use HTTPS em produção
- ⚠️ Implemente backup regular

## 📱 Responsividade

O sistema é totalmente responsivo e funciona em:
- 💻 Desktop
- 📱 Tablets
- 📱 Smartphones

## 🎨 Capturas de Tela

### Desktop
![Desktop](https://via.placeholder.com/800x600?text=Desktop+View)

### Mobile
![Mobile](https://via.placeholder.com/400x800?text=Mobile+View)

### PDF Gerado
![PDF](https://via.placeholder.com/800x600?text=PDF+Example)

## 🐛 Solução de Problemas

### Documentos não aparecem no PDF
✅ **Resolvido na versão atual!** Todos os documentos são incluídos automaticamente.

### Não consigo importar a ficha
- Verifique se o arquivo é `.json`
- Certifique-se que não foi corrompido
- Tente exportar novamente

### Sincronização online não funciona
- Verifique se o backend está rodando
- Confirme a URL da API no código
- Veja o console do navegador (F12) para erros

### Câmera não funciona
- Use HTTPS ou localhost
- Permita acesso à câmera no navegador
- Verifique se o dispositivo tem câmera

## 🚀 Roadmap

### Versão 1.1 (Próxima)
- [ ] Autenticação de usuários
- [ ] Dashboard de gestão
- [ ] Relatórios e estatísticas
- [ ] Exportação em lote

### Versão 2.0 (Futuro)
- [ ] Assinatura digital
- [ ] Integração com eSocial
- [ ] Notificações por e-mail
- [ ] Versionamento de fichas
- [ ] Auditoria de alterações

## 🤝 Contribuindo

Contribuições são bem-vindas! Sinta-se à vontade para:

1. Fazer um fork do projeto
2. Criar uma branch para sua feature (`git checkout -b feature/MinhaFeature`)
3. Commit suas mudanças (`git commit -m 'Adiciona MinhaFeature'`)
4. Push para a branch (`git push origin feature/MinhaFeature`)
5. Abrir um Pull Request

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo [LICENSE](LICENSE) para mais detalhes.

## 👤 Autor

Desenvolvido com ❤️ para facilitar o trabalho do RH

## 📞 Suporte

Para dúvidas ou problemas:
- 📖 Consulte o [GUIA_COMPLETO.md](GUIA_COMPLETO.md)
- 🐛 Abra uma [issue](https://github.com/SEU-USUARIO/ficha-registro-rh/issues)
- 💬 Entre em contato

## ⭐ Agradecimentos

- [jsPDF](https://github.com/parallax/jsPDF) pela biblioteca de geração de PDF
- [ViaCEP](https://viacep.com.br/) pela API de CEP gratuita
- Comunidade open source

---

**Se este projeto foi útil, deixe uma ⭐ no repositório!**

